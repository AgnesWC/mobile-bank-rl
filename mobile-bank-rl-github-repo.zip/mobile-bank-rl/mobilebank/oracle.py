"""Value-iteration benchmark ("oracle").

Uses the simulator's model with the TRUE district parameters and the EXACT
state (exact waiting times capped at 7 days, exact operating day of the
cycle, road condition): 5 x 6^4 x 24 x 2 = 311,040 states. One stationary
solution per cycle type (rainy, March, rest of the marketing season, lean),
assuming that cycle type repeats. It ignores demand drift, the yearly
+/-20% peak draws and unbanked-pool depletion,
so it is a strong planner with information the agent never has, not a
guaranteed optimum of the full simulator.
"""
import numpy as np
from scipy.stats import nbinom

from . import config as C

AGES = np.arange(2, 8)        # 2..7 (7 = 7 or more)
NA = len(AGES)
N_ORACLE = 5 * NA**4 * C.OP_DAYS * 2

# cycle types: (season, a cycle of that type, the cycles that use it)
CYCLE_TYPES = {
    "rainy": (0, 0, [0, 1, 2, 3]),
    "marketing (March)": (1, C.MARCH_CYCLE, [4]),
    "marketing": (1, 5, [5, 6, 7, 8]),
    "lean": (2, 9, [9, 10, 11, 12]),
}


def _expected_min(mu, cap):
    """E[min(D, cap)] = sum_{j<cap} P(D > j), D negative binomial with mean mu."""
    j = np.arange(cap)
    k = C.DEMAND_K
    return nbinom.sf(j[None, :], k, (k / (k + mu))[:, None]).sum(axis=1)


def others_of(l):
    return [j for j in range(5) if j != l]


def op_weekday(d):
    return d % 6               # 0 = Monday ... 5 = Saturday


def solve(params, rho_scale=C.RHO_TRAINING_SCALE, reward_design="R1", w_u=C.W_U,
          tol=1e-3, max_iter=2000):
    policies = {}
    # enumerate states
    l, code, d, wet = np.meshgrid(np.arange(5), np.arange(NA**4), np.arange(C.OP_DAYS),
                                  np.arange(2), indexing="ij")
    l, code, d, wet = l.ravel(), code.ravel(), d.ravel(), wet.ravel()
    digits = np.stack([(code // NA**(3 - k)) % NA for k in range(4)], axis=1)
    ages_others = AGES[digits]                      # (S, 4)
    S = len(l)
    # full age vector per state (current site gets age since its last service)
    delta_prev = np.where(op_weekday(d) == 0, 2, 1)
    full = np.zeros((S, 5), int)
    for li in range(5):
        m = l == li
        full[np.ix_(m, others_of(li))] = ages_others[m]
        full[m, li] = delta_prev[m]
    delta = np.where(op_weekday(d) == 5, 2, 1)       # Saturday -> skip Sunday
    week = (d // 6)
    next_d = (d + 1) % C.OP_DAYS

    for name, (season, rep_cycle, cycles) in CYCLE_TYPES.items():
        R = np.zeros((S, 5))
        NXT0 = np.zeros((S, 5), int)
        for a in range(5):
            stayed = (l == a)
            age_a = full[:, a]
            psi = np.where(stayed, 0.3, np.where(age_a <= 2, 0.7, np.where(age_a <= 6, 1.0, 1.3)))
            h = np.where((wet == 1) & bool(C.GRAVEL[a]), C.WET_GRAVEL_HOURS, 1.0)
            kappa = np.ones(S)
            if a in C.PEAK_MONTH_END:
                kappa = np.where(week == 3, C.PEAK_MONTH_END[a], 1.0)
            if C.in_season_peak(a, season):
                kappa = kappa * C.PEAK_SEASON[a][1]
            peak = (week == 3) | (a == 1 and season == 1)
            mu = params["lam0"][a] * kappa * psi * h * C.WEEKDAY_MULT[op_weekday(d)]
            umu, inv = np.unique(np.round(mu, 3), return_inverse=True)
            es = _expected_min(umu, C.CAPACITY_TX)[inv]
            et = mu - es
            ea = np.minimum(params["uptake"][a] * es, C.CAPACITY_ACC)
            q = params["rho"][a] * rho_scale * np.where(peak, C.RISK_MULT_PEAK, 1.0)
            km = C.DIST[l, a]
            bonus = 0.0
            if reward_design == "R1" and C.UNDERSERVED[a]:
                bonus = np.where((~stayed) & (age_a >= 3), w_u, 0.0)
            R[:, a] = ((1 - q / 2) * (C.W_N * es + C.W_A * ea) + bonus - C.W_T * et
                       - C.C_KM * km - C.C_DAY - C.L_INC * q)
            # next ages
            new_full = np.minimum(full + delta[:, None], 7)
            new_full[:, a] = 0
            if reward_design == "R2":
                for j in np.flatnonzero(C.UNDERSERVED):
                    if j != a:
                        R[:, a] -= C.P_OVERDUE * (new_full[:, j] >= 7)
            oth = others_of(a)
            nd = np.clip(new_full[:, oth], 2, 7) - 2
            ncode = ((nd[:, 0] * NA + nd[:, 1]) * NA + nd[:, 2]) * NA + nd[:, 3]
            NXT0[:, a] = ((a * NA**4 + ncode) * C.OP_DAYS + next_d) * 2
        p_ww, p_wd = C.p_wet(rep_cycle, True), C.p_wet(rep_cycle, False)
        pwet = np.where(wet == 1, p_ww, p_wd)[:, None]
        V = np.zeros(S)
        for it in range(max_iter):
            Q = R + C.GAMMA * (pwet * V[NXT0 + 1] + (1 - pwet) * V[NXT0])
            V2 = Q.max(axis=1)
            if np.abs(V2 - V).max() < tol:
                V = V2
                break
            V = V2
        policies[name] = (Q.argmax(axis=1), V, it)
    return policies


class Oracle:
    name = "Oracle (value iteration)"

    def __init__(self, params, **kw):
        self.pol = solve(params, **kw)
        self.type_of = {}
        for name, (_, _, cycles) in CYCLE_TYPES.items():
            for c in cycles:
                self.type_of[c] = name

    def index(self, info):
        l = info["loc"]
        ages = np.clip(info["ages"][others_of(l)], 2, 7) - 2
        code = ((ages[0] * NA + ages[1]) * NA + ages[2]) * NA + ages[3]
        day = info["day"]
        d = (day // 7) * 6 + (day % 7)       # calendar day -> operating day
        return ((l * NA**4 + code) * C.OP_DAYS + d) * 2 + int(info["wet"])

    def act(self, s, info, explore=False):
        return int(self.pol[self.type_of[info["cycle"]]][0][self.index(info)])

    def observe_outcome(self, info):
        pass