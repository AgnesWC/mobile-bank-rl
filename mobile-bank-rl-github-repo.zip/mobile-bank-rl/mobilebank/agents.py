"""Tabular learners. The policy is a lookup table Q[s, a] (9,720 x 5).

QLearning        - main learner (off-policy TD control)
ExpectedSarsa    - on-policy comparison (safer during training)
MonteCarlo       - every-visit constant-alpha MC on 24-step cycles
CountBonusQ      - Q-learning that explores with a count-based bonus
"""
import numpy as np

from . import config as C
from .env import n_states


class TabularAgent:
    name = "tabular"

    def __init__(self, alpha=0.005, gamma=C.GAMMA, eps_start=1.0, eps_min=0.05,
                 decay_years=1200, safe=True, seed=0, harmonic=True, bins="3"):
        self.bins = bins
        self.Q = np.zeros((n_states(bins), C.N_SITES))
        self.N = np.zeros((n_states(bins), C.N_SITES), dtype=np.int32)   # visit counts
        self.alpha, self.gamma = alpha, gamma
        self.eps_start, self.eps_min, self.decay_years = eps_start, eps_min, decay_years
        self.eps = eps_start
        self.harmonic = harmonic
        self.safe = safe
        self.rng = np.random.default_rng(seed)
        # agent's own estimate of incident rate per site: Beta(1, 50) prior
        self.inc = np.ones(5)
        self.vis = np.full(5, 50.0)
        # visit records the bank would keep (for kiosk siting)
        self.records = [[] for _ in range(5)]

    # ---------------------------------------------------------------- policy
    def set_year(self, year):
        """Linear epsilon decay from eps_start to eps_min over decay_years."""
        frac = min(year / max(self.decay_years, 1), 1.0)
        self.eps = self.eps_start + frac * (self.eps_min - self.eps_start)

    def greedy(self, s):
        q = self.Q[s]
        best = np.flatnonzero(q == q.max())
        return int(self.rng.choice(best))           # random tie-break

    def allowed_explore(self, info):
        """Safety mask, applied to exploratory actions only.
        safe=True: (1) no gravel destination more than 90 km away on a wet
        morning; (2) in month-end week, not the site with the highest incident
        rate in the agent's own records.
        safe="proposal": also (3) not the tobacco ward in the marketing season,
        as written in Assignment A."""
        acts = list(range(5))
        if not self.safe:
            return acts
        loc = info["loc"]
        if info["wet"]:
            acts = [a for a in acts if not (C.GRAVEL[a] and C.DIST[loc, a] > 90)]
        if info["week"] == 3:
            riskiest = int(np.argmax(self.inc / self.vis))
            acts = [a for a in acts if a != riskiest] or acts
        if self.safe == "proposal" and info["season"] == 1:
            acts = [a for a in acts if a != 1] or acts
        return acts

    def act(self, s, info, explore=True):
        if explore and self.rng.random() < self.eps:
            return int(self.rng.choice(self.allowed_explore(info)))
        return self.greedy(s)

    def policy_probs(self, s):
        """Probabilities of the epsilon-greedy policy (mask ignored)."""
        p = np.full(5, self.eps / 5)
        best = np.flatnonzero(self.Q[s] == self.Q[s].max())
        p[best] += (1 - self.eps) / len(best)
        return p

    # ---------------------------------------------------------------- learning
    def lr(self, s, a):
        """Step size: 1/N(s,a) early (a running average), never below alpha,
        so the table keeps tracking demand drift once it has data."""
        if self.harmonic:
            return max(1.0 / self.N[s, a], self.alpha)
        return self.alpha

    def observe_outcome(self, info):
        a = info["site"]
        self.inc[a] += info["incident"]
        self.vis[a] += 1
        # demand estimate per visit, corrected for pent-up demand and lost hours
        self.records[a].append(info["served"])

    def update(self, s, a, r, s2, info):
        raise NotImplementedError

    def end_cycle(self):
        pass


class QLearning(TabularAgent):
    name = "Q-learning"

    def update(self, s, a, r, s2, info):
        self.N[s, a] += 1
        target = r + self.gamma * self.Q[s2].max()      # bootstrap: no terminal states
        self.Q[s, a] += self.lr(s, a) * (target - self.Q[s, a])


class ExpectedSarsa(TabularAgent):
    name = "Expected SARSA"

    def update(self, s, a, r, s2, info):
        self.N[s, a] += 1
        target = r + self.gamma * self.policy_probs(s2) @ self.Q[s2]
        self.Q[s, a] += self.lr(s, a) * (target - self.Q[s, a])


class CountBonusQ(QLearning):
    """Acts greedily on Q + beta / sqrt(n + 1); small epsilon floor kept."""
    name = "Q-learning + count bonus"

    def __init__(self, beta=50.0, **kw):
        kw.setdefault("eps_start", 0.05)
        super().__init__(**kw)
        self.beta = beta

    def act(self, s, info, explore=True):
        if not explore:
            return self.greedy(s)
        if self.rng.random() < self.eps:
            return int(self.rng.choice(self.allowed_explore(info)))
        score = self.Q[s] + self.beta / np.sqrt(self.N[s] + 1)
        best = np.flatnonzero(score == score.max())
        return int(self.rng.choice(best))

    def set_year(self, year):
        self.eps = self.eps_min


class MonteCarlo(TabularAgent):
    """Every-visit, constant-alpha MC control over one 24-step cycle.
    The cycle is truncated, not terminal, so the return is completed with
    gamma^k * max Q(s_end) (bootstrapped tail)."""
    name = "Monte Carlo"

    def __init__(self, **kw):
        super().__init__(**kw)
        self.buffer = []

    def update(self, s, a, r, s2, info):
        self.N[s, a] += 1
        self.buffer.append((s, a, r))
        self.last_next = s2

    def end_cycle(self):
        G = self.Q[self.last_next].max()
        for s, a, r in reversed(self.buffer):
            G = r + self.gamma * G
            self.Q[s, a] += self.lr(s, a) * (G - self.Q[s, a])
        self.buffer = []


# -------------------------------------------------------------------- bandits
class Bandit:
    """Layer 1: each site is an arm; state, travel and calendar ignored."""

    def __init__(self, kind="egreedy", eps=0.1, alpha=0.1, init=0.0, temp=(50, 5),
                 c=2.0, disc=0.97, seed=0, horizon=1):
        self.kind, self.eps, self.alpha, self.c, self.disc = kind, eps, alpha, c, disc
        self.q = np.full(5, float(init))
        self.n = np.zeros(5)
        self.dn = np.zeros(5)      # discounted counts (D-UCB)
        self.dsum = np.zeros(5)    # discounted reward sums (D-UCB)
        self.t = 0
        self.temp0, self.temp1 = temp
        self.horizon = horizon
        self.rng = np.random.default_rng(seed)
        self.lo, self.hi = -1600.0, 400.0    # reward range used to rescale to [0, 1] for UCB

    def scale(self, r):
        return (r - self.lo) / (self.hi - self.lo)

    def act(self):
        self.t += 1
        if self.kind in ("egreedy", "optimistic"):
            if self.rng.random() < self.eps:
                return int(self.rng.integers(5))
            return int(np.argmax(self.q))
        if self.kind == "softmax":
            frac = min(self.t / self.horizon, 1.0)
            temp = self.temp0 + frac * (self.temp1 - self.temp0)
            z = (self.q - self.q.max()) / temp
            p = np.exp(z) / np.exp(z).sum()
            return int(self.rng.choice(5, p=p))
        if self.kind == "ucb":
            if (self.n == 0).any():
                return int(np.argmin(self.n))
            return int(np.argmax(self.q + self.c * np.sqrt(np.log(self.t) / self.n)))
        if self.kind == "ducb":
            if (self.dn < 1e-9).any():
                return int(np.argmin(self.dn))
            mean = self.dsum / self.dn
            bonus = self.c * np.sqrt(np.log(self.dn.sum()) / self.dn)
            return int(np.argmax(mean + bonus))
        raise ValueError(self.kind)

    def update(self, a, r):
        self.n[a] += 1
        if self.kind in ("ucb",):
            x = self.scale(r)
            self.q[a] += (x - self.q[a]) / self.n[a]
        elif self.kind == "ducb":
            self.dn *= self.disc
            self.dsum *= self.disc
            self.dn[a] += 1
            self.dsum[a] += self.scale(r)
        else:
            self.q[a] += self.alpha * (r - self.q[a])