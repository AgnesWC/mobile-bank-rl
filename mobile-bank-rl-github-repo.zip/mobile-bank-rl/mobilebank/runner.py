"""Training loop and evaluation loop."""
import numpy as np

from . import config as C
from .env import MobileBankEnv
from .baselines import GreedyAverage


def train(agent, env, years, checkpoint_years=(), on_cycle=None, start_year=0):
    """The training algorithm.

    for each simulated year:
        set epsilon for this year (linear decay to a floor)
        for each 28-day cycle (24 operating days):
            observe state s
            choose a with epsilon-greedy (safety mask on exploratory actions)
            step the simulator -> reward r, next state s2, truncated flag
            update the table: Q[s,a] += alpha * (target - Q[s,a])
            (the cycle end is truncation, not termination, so the target
             always bootstraps from s2)
    Returns a log of per-cycle returns and saved greedy-policy snapshots.
    """
    s, info = env._obs(), env._info()
    log = dict(cycle_return=[], cycle_incidents=[], risky_trips=[], eps=[])
    snapshots = {}
    for year in range(start_year, start_year + years):
        agent.set_year(year)
        for _ in range(C.CYCLES_PER_YEAR):
            G, inc, risky = 0.0, 0, 0
            while True:
                a = agent.act(s, info, explore=True)
                s2, r, terminated, truncated, info2 = env.step(a)
                agent.update(s, a, r, s2, info2)
                agent.observe_outcome(info2)
                G += r
                inc += info2["incident"]
                risky += info2["peak"]
                s, info = s2, info2
                if truncated:
                    break
            agent.end_cycle()
            log["cycle_return"].append(G)
            log["cycle_incidents"].append(inc)
            log["risky_trips"].append(risky)
            log["eps"].append(agent.eps)
            if on_cycle:
                on_cycle(agent, log)
        if (year + 1) in checkpoint_years:
            snapshots[year + 1] = agent.Q.argmax(axis=1).copy()
    return log, snapshots


def evaluate(policy, params, seed, years, env_kwargs=None, explore=False,
             softmax_temp=None):
    """Run a frozen policy on fresh simulated years of the same district.
    Returns per-cycle metrics and the list of (week, season, site) choices."""
    kw = dict(env_kwargs or {})
    if hasattr(policy, "bins"):
        kw.setdefault("bins", policy.bins)
    env = MobileBankEnv(**kw)
    s, info = env.reset(seed=seed, params=params)
    rng = np.random.default_rng(seed + 999)
    rows, choices, states = [], [], []
    for _ in range(years * C.CYCLES_PER_YEAR):
        m = dict(ret=0.0, surplus=0.0, served=0, turned=0, accounts=0, km=0.0,
                 incidents=0, under_visits=0, visits=0, max_gap=0)
        while True:
            for j in np.flatnonzero(C.UNDERSERVED):
                m["max_gap"] = max(m["max_gap"], int(info["ages"][j]))
            if softmax_temp:
                z = (policy.Q[s] - policy.Q[s].max()) / softmax_temp
                p = np.exp(z) / np.exp(z).sum()
                a = int(rng.choice(5, p=p))
            else:
                a = policy.act(s, info, explore=explore)
            choices.append((info["week"], info["season"], a))
            states.append(s)
            s2, r, _, truncated, info2 = env.step(a)
            if isinstance(policy, GreedyAverage):
                policy.record(a, r)
            m["ret"] += r
            m["surplus"] += r - info2["bonus"]
            m["served"] += info2["served"]
            m["turned"] += info2["turned_away"]
            m["accounts"] += info2["accounts"]
            m["km"] += info2["km"]
            m["incidents"] += info2["incident"]
            m["under_visits"] += int(C.UNDERSERVED[a])
            m["visits"] += 1
            s, info = s2, info2
            if truncated:
                break
        rows.append(m)
    return rows, choices, states


def summarise(rows):
    keys = rows[0].keys()
    out = {k: float(np.mean([r[k] for r in rows])) for k in keys}
    rets = np.sort([r["ret"] for r in rows])
    k = max(1, int(0.05 * len(rets)))
    out["cvar5"] = float(rets[:k].mean())
    out["max_gap_overall"] = int(max(r["max_gap"] for r in rows))
    out["under_share"] = out["under_visits"] / out["visits"]
    return out


def schedule_entropy(choices):
    """Mean entropy (bits) of the site choice for each (week, season) pair."""
    from collections import Counter, defaultdict
    groups = defaultdict(Counter)
    for w, s, a in choices:
        groups[(w, s)][a] += 1
    ents = []
    for c in groups.values():
        p = np.array(list(c.values()), float)
        p /= p.sum()
        ents.append(float(-(p * np.log2(p)).sum()))
    return float(np.mean(ents))