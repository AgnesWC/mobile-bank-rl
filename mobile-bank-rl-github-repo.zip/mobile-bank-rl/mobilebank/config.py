"""All simulator parameters in one place.

Every number here is an ASSUMPTION. The sites are the five archetypes of
Assignment A (Section 3.1); values marked [A] are taken from Assignment A,
values marked [B] were added or changed for Assignment B (see the report).
"""
import json
import os

import numpy as np

# ---------------------------------------------------------------- dataset
# [B] Shape of daily demand, measured on the Wisabi Bank dataset (Kaggle, CC0)
# by calibrate.py: 2,143,838 ATM transactions at 50 locations in 2022.
_CAL = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                   "..", "data", "calibration.json")))
WEEKDAY_MULT = np.array(_CAL["weekday_multiplier_mon_to_sat"])   # Monday..Saturday
DEMAND_K = _CAL["dispersion_k"]      # negative-binomial size: Var = mu + mu^2 / k
MINUTES_PER_TX = _CAL["minutes_per_transaction"]                 # 4.14, supports [A] 4 minutes

# ---------------------------------------------------------------- sites
SITES = ["District town", "Tobacco ward", "Communal ward", "Mining settlement",
         "Irrigation scheme"]
SHORT = ["A", "B", "C", "D", "E"]
N_SITES = 5

UNDERSERVED = np.array([0, 1, 1, 0, 1])   # [A] u_i: no kiosk or agent nearby
GRAVEL = np.array([0, 1, 1, 0, 1])        # [A] gravel road (slowed by rain)

# [A] base demand range per operating day, drawn once per district (seed)
LAMBDA_RANGE = np.array([[70, 90], [30, 50], [25, 40], [50, 70], [30, 45]], float)

# [A] road distances in km (assumed)
_D = {("A", "B"): 45, ("A", "C"): 60, ("A", "D"): 35, ("A", "E"): 70, ("B", "C"): 40,
      ("B", "D"): 75, ("B", "E"): 105, ("C", "D"): 90, ("C", "E"): 55, ("D", "E"): 85}
DIST = np.zeros((5, 5))
for (a, b), km in _D.items():
    i, j = SHORT.index(a), SHORT.index(b)
    DIST[i, j] = DIST[j, i] = km

# ---------------------------------------------------------------- calendar
CYCLE_DAYS = 28          # [A] 4 weeks; Sundays (weekday 6) are rest days
OP_DAYS = 24             # decisions per cycle
CYCLES_PER_YEAR = 13     # [A] 364-day year, starting 1 November
# [A] season of each cycle: 0 rainy (Nov-Feb), 1 marketing (Mar-Jul),
# 2 lean (Aug-Oct). [B] boundaries rounded to whole cycles:
# rainy 1 Nov-20 Feb, marketing 21 Feb-10 Jul, lean 11 Jul-30 Oct.
SEASON_OF_CYCLE = np.array([0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2])
MARCH_CYCLE = 4          # 21 Feb-20 Mar: the only non-rainy cycle with wet mornings

# mean peak multipliers; [A] each year draws its own value within +/-20%
PEAK_MONTH_END = {0: 1.3, 2: 1.8}   # week 4: district town ([B] x1.3), communal ward ([A] x1.8)
PEAK_SEASON = {1: (1, 2.2),         # [A] tobacco ward in the marketing season
               4: (2, 1.4)}         # [A] irrigation scheme in the lean season


def in_season_peak(i, season):
    return i in PEAK_SEASON and PEAK_SEASON[i][0] == season


def high_risk(i, week, season):
    """[A] incident risk x3 in month-end week, and at the tobacco ward in the marketing season."""
    return week == 3 or (i == 1 and season == 1)


# ---------------------------------------------------------------- demand
CAPACITY_TX = 120        # [A] transactions per day (4 min each, 08:00-16:30)
CAPACITY_ACC = 25        # [A] new accounts per day (15 min each)


def psi(age, stayed):
    """[A] pent-up demand factor by days since the site was last served."""
    if stayed:
        return 0.3
    if age <= 2:
        return 0.7
    if age <= 6:
        return 1.0
    return 1.3


WET_GRAVEL_HOURS = 0.6   # [A] share of the day left on a wet gravel road

UPTAKE_RANGE = (0.05, 0.15)                                       # [A] account uptake p_i
UNBANKED_POOL = np.array([2500, 2000, 2000, 2000, 2000], float)   # [B] B0_i
POOL_REGROWTH = 0.3      # [B] share of the gap to B0 refilled at each new year

# demand drift, updated every cycle. [A] log-normal step with sd 0.05;
# [B] made mean-reverting (AR(1)) so demand stays bounded over long runs
DRIFT_PHI = 0.9
DRIFT_SD = 0.05

# ---------------------------------------------------------------- roads
# [A] rainy season: P(wet | wet) = 0.6, P(wet | dry) = 0.25; March 0.05; else never
WET_RAINY = (0.60, 0.25)
WET_MARCH = 0.05


def p_wet(cycle, wet_now):
    if SEASON_OF_CYCLE[cycle] == 0:
        return WET_RAINY[0] if wet_now else WET_RAINY[1]
    return WET_MARCH if cycle == MARCH_CYCLE else 0.0


# ---------------------------------------------------------------- incidents
RHO_RANGE = (0.002, 0.010)   # [A] daily incident probability
RHO_TRAINING_SCALE = 2.0     # [B] raised twofold so incidents occur often enough to learn from
                             #     ([A] proposed fivefold; every rule-based policy then lost money)
RISK_MULT_PEAK = 3.0         # [A]

# ---------------------------------------------------------------- reward [A]
W_N = 1.0      # per transaction served
W_A = 8.0      # per new account
W_U = 40.0     # under-served bonus (R1), paid if the ward waited >= 3 days
W_T = 0.5      # per customer turned away
C_KM = 0.4     # per km driven
C_DAY = 60.0   # fixed cost per operating day
L_INC = 1500.0 # loss per security incident
P_OVERDUE = 15.0  # [B] R2: daily penalty per under-served ward waiting >= 7 days

GAMMA = 0.95   # [A]