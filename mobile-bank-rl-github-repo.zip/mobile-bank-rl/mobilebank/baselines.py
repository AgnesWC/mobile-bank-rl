"""Rule-based baselines. Each sees the env's info dict (exact ages, calendar)."""
import numpy as np

from . import config as C


class Baseline:
    name = "baseline"

    def __init__(self, seed=0):
        self.rng = np.random.default_rng(seed)

    def observe_outcome(self, info):
        pass


class RandomPolicy(Baseline):
    name = "Random"

    def act(self, s, info, explore=False):
        return int(self.rng.integers(5))


class FixedRotation(Baseline):
    name = "Fixed rotation"

    def act(self, s, info, explore=False):
        return (info["loc"] + 1) % 5          # A, B, C, D, E, A, ...


class GreedyAverage(Baseline):
    """Site with the best average reward so far (sample average)."""
    name = "Greedy average"

    def __init__(self, seed=0):
        super().__init__(seed)
        self.total = np.zeros(5)
        self.n = np.zeros(5)

    def act(self, s, info, explore=False):
        if (self.n == 0).any():
            return int(np.argmin(self.n))
        return int(np.argmax(self.total / self.n))

    def record(self, a, r):
        self.total[a] += r
        self.n[a] += 1


class NearestOverdue(GreedyAverage):
    name = "Nearest overdue"

    def act(self, s, info, explore=False):
        ages, loc = info["ages"], info["loc"]
        overdue = [j for j in range(5) if j != loc and ages[j] >= 7]
        if overdue:
            return int(min(overdue, key=lambda j: C.DIST[loc, j]))
        return super().act(s, info)


class CalendarPlanner(Baseline):
    """What a sensible manager would do with the seasonal calendar (Assignment A):
    tobacco ward (B) in the marketing season, communal ward (C) in month-end
    week, irrigation scheme (E) in the lean season, each only if it has waited
    3 days or more; otherwise the site that has waited longest."""
    name = "Calendar planner"

    def act(self, s, info, explore=False):
        ages, loc = info["ages"], info["loc"]
        wishes = []
        if info["week"] == 3:
            wishes.append(2)
        if info["season"] == 1:
            wishes.append(1)
        if info["season"] == 2:
            wishes.append(4)
        for j in wishes:
            if ages[j] >= 3 and j != loc:
                return j
        cand = [j for j in range(5) if j != loc]
        return int(max(cand, key=lambda j: (ages[j], -C.DIST[loc, j])))