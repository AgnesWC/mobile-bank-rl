"""Coverage rule applied on top of a trained table at deployment."""
import numpy as np

from . import config as C


class CoverageShield:
    """Deployment wrapper: if an under-served ward has waited `limit` days or
    more, go to the one that has waited longest; otherwise follow the table."""
    name = "Q-learning + coverage rule"

    def __init__(self, agent, limit=7):
        self.agent, self.limit, self.bins = agent, limit, agent.bins
        self.overrides, self.calls = 0, 0

    def act(self, s, info, explore=False):
        self.calls += 1
        ages, loc = info["ages"], info["loc"]
        due = [j for j in np.flatnonzero(C.UNDERSERVED) if j != loc and ages[j] >= self.limit]
        if due:
            self.overrides += 1
            return int(max(due, key=lambda j: ages[j]))
        return self.agent.act(s, info, explore=False)

    def observe_outcome(self, info):
        pass