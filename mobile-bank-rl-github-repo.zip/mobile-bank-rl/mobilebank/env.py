"""Gymnasium environment: one mobile bank unit, five growth points.

One step = one operating day (Monday to Saturday). A 28-day cycle has
24 steps. At the end of a cycle the env returns truncated=True, but the
state carries over: the problem is continuing, so learners must still
bootstrap from the next state (Pardo et al., 2018).
"""
import numpy as np
import gymnasium as gym
from gymnasium import spaces

from . import config as C

# Waiting-time buckets shown to the agent.
#   "3": fresh (<=2 days), due (3-6), overdue (7+)            -> 9,720 states
#   "4": 2 days, 3-4, 5-6, 7+ (splits "due" in two)           -> 30,720 states
AGE_EDGES = {"3": (2, 6), "4": (2, 4, 6)}


def n_states(bins="3"):
    nb = len(AGE_EDGES[bins]) + 1
    return 5 * nb**4 * 4 * 3 * 2


N_STATES = n_states("3")   # 9,720


def bucket(age, bins="3"):
    for k, edge in enumerate(AGE_EDGES[bins]):
        if age <= edge:
            return k
    return len(AGE_EDGES[bins])


class MobileBankEnv(gym.Env):
    metadata = {"render_modes": []}

    def __init__(self, reward_design="R1", w_u=C.W_U, rho_scale=C.RHO_TRAINING_SCALE,
                 drift=True, lambda_scale=1.0, wet_scale=1.0, bins="3"):
        super().__init__()
        self.bins = bins
        self.nb = len(AGE_EDGES[bins]) + 1
        self.observation_space = spaces.Discrete(n_states(bins))
        self.action_space = spaces.Discrete(C.N_SITES)
        self.reward_design = reward_design
        self.w_u = w_u
        self.rho_scale = rho_scale
        self.drift = drift
        self.lambda_scale = lambda_scale   # stress tests
        self.wet_scale = wet_scale         # stress tests
        self.params = None

    # ------------------------------------------------------------ setup
    def draw_district(self, rng):
        """Hidden parameters of one district. Fixed for the whole run."""
        lo, hi = C.LAMBDA_RANGE[:, 0], C.LAMBDA_RANGE[:, 1]
        return dict(
            lam0=rng.uniform(lo, hi),
            uptake=rng.uniform(*C.UPTAKE_RANGE, size=5),
            rho=rng.uniform(*C.RHO_RANGE, size=5),
        )

    def reset(self, seed=None, options=None, params=None):
        """Start a district. `params` lets several policies face the same district."""
        super().reset(seed=seed)
        rng = self.np_random
        self.params = params if params is not None else self.draw_district(rng)
        self.log_drift = np.zeros(5)
        self.pool = C.UNBANKED_POOL.copy()
        self.t_abs = 0                     # calendar day since start (incl. Sundays)
        self.last_served = np.full(5, -8)  # all outlying sites start overdue
        self.loc = 0                       # starts at the district town (depot)
        self.last_served[0] = -2           # served on the previous Saturday
        self.wet = False
        self.year = 0
        self._new_year()
        return self._obs(), self._info()

    def _new_year(self):
        rng = self.np_random
        self.peak = dict(
            month_end={k: v * rng.uniform(0.8, 1.2) for k, v in C.PEAK_MONTH_END.items()},
            season={k: v[1] * rng.uniform(0.8, 1.2) for k, v in C.PEAK_SEASON.items()},
        )
        self.pool += C.POOL_REGROWTH * (C.UNBANKED_POOL - self.pool)

    # ------------------------------------------------------------ calendar
    @property
    def day_in_cycle(self):
        return self.t_abs % C.CYCLE_DAYS

    @property
    def cycle(self):
        return (self.t_abs // C.CYCLE_DAYS) % C.CYCLES_PER_YEAR

    @property
    def week(self):
        return self.day_in_cycle // 7      # 0..3, 3 = month-end week

    @property
    def season(self):
        return int(C.SEASON_OF_CYCLE[self.cycle])

    def ages(self):
        return self.t_abs - self.last_served

    def peak_site(self, i):
        """Days on which incident risk is tripled."""
        return C.high_risk(i, self.week, self.season)

    def kappa(self, i):
        """Calendar multiplier of site i today."""
        k = 1.0
        if i in C.PEAK_MONTH_END and self.week == 3:
            k *= self.peak["month_end"][i]
        if C.in_season_peak(i, self.season):
            k *= self.peak["season"][i]
        return k

    # ------------------------------------------------------------ observation
    def _obs(self):
        ages = self.ages()
        others = [j for j in range(5) if j != self.loc]
        code = 0
        for j in others:
            code = code * self.nb + bucket(ages[j], self.bins)
        idx = self.loc
        idx = idx * self.nb**4 + code
        idx = idx * 4 + self.week
        idx = idx * 3 + self.season
        idx = idx * 2 + int(self.wet)
        return idx

    def _info(self):
        return dict(loc=self.loc, ages=self.ages().copy(), week=self.week,
                    season=self.season, cycle=self.cycle, wet=self.wet,
                    day=self.day_in_cycle, year=self.year)

    # ------------------------------------------------------------ dynamics
    def step(self, action):
        a = int(action)
        rng = self.np_random
        p = self.params
        ages = self.ages()
        stayed = (a == self.loc)
        km = C.DIST[self.loc, a]
        h = C.WET_GRAVEL_HOURS if (self.wet and C.GRAVEL[a]) else 1.0
        lam = p["lam0"][a] * np.exp(self.log_drift[a]) * self.lambda_scale
        weekday = C.WEEKDAY_MULT[self.t_abs % 7]
        mu = lam * self.kappa(a) * C.psi(ages[a], stayed) * h * weekday

        # negative binomial with mean mu: more day-to-day spread than Poisson,
        # as measured on the Wisabi dataset
        demand = rng.negative_binomial(C.DEMAND_K, C.DEMAND_K / (C.DEMAND_K + mu))
        served = min(demand, C.CAPACITY_TX)
        turned_away = demand - served
        p_acc = p["uptake"][a] * self.pool[a] / C.UNBANKED_POOL[a]
        accounts = min(rng.binomial(served, p_acc), C.CAPACITY_ACC)

        risk = p["rho"][a] * self.rho_scale * (C.RISK_MULT_PEAK if self.peak_site(a) else 1.0)
        incident = rng.random() < risk
        if incident:                       # operations stop early
            served //= 2
            accounts //= 2
        self.pool[a] = max(self.pool[a] - accounts, 0.0)

        bonus = 0.0
        if self.reward_design == "R1":
            if C.UNDERSERVED[a] and not stayed and ages[a] >= 3:
                bonus = self.w_u
        reward = (C.W_N * served + C.W_A * accounts + bonus - C.W_T * turned_away
                  - C.C_KM * km - C.C_DAY - C.L_INC * incident)

        # ---- advance the calendar (skip Sunday)
        self.last_served[a] = self.t_abs
        self.loc = a
        step_days = 2 if self.t_abs % 7 == 5 else 1
        old_cycle_abs = self.t_abs // C.CYCLE_DAYS
        self.t_abs += step_days
        new_cycle_abs = self.t_abs // C.CYCLE_DAYS
        truncated = new_cycle_abs != old_cycle_abs

        if self.reward_design == "R2":     # penalty for overdue under-served wards
            new_ages = self.ages()
            overdue = [(C.UNDERSERVED[j] and new_ages[j] >= 7 and j != a) for j in range(5)]
            reward -= C.P_OVERDUE * sum(overdue)

        if truncated:
            if self.drift:
                self.log_drift = C.DRIFT_PHI * self.log_drift + rng.normal(0, C.DRIFT_SD, 5)
            if self.cycle == 0:
                self.year += 1
                self._new_year()

        p_wet = C.p_wet(self.cycle, self.wet) * self.wet_scale
        self.wet = bool(rng.random() < min(p_wet, 1.0))

        info = self._info()
        info.update(served=served, turned_away=turned_away, accounts=accounts,
                    incident=bool(incident), km=km, site=a, bonus=bonus,
                    demand_seen=served, stayed=stayed, peak=self.peak_site(a))
        return self._obs(), float(reward), False, truncated, info


def decode(idx, bins="3"):
    """Inverse of _obs, for reading the Q-table."""
    nb = len(AGE_EDGES[bins]) + 1
    wet = idx % 2; idx //= 2
    season = idx % 3; idx //= 3
    week = idx % 4; idx //= 4
    code = idx % nb**4; loc = idx // nb**4
    b = []
    for _ in range(4):
        b.append(code % nb); code //= nb
    return dict(loc=loc, buckets=b[::-1], week=week, season=season, wet=wet)